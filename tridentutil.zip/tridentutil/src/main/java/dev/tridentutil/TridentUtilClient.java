package dev.tridentutil;

import com.mojang.blaze3d.platform.InputConstants;
import dev.tridentutil.config.TridentConfig;
import dev.tridentutil.gui.TridentConfigScreen;
import dev.tridentutil.hud.TridentHud;
import dev.tridentutil.trajectory.TrajectoryPreview;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

public class TridentUtilClient implements ClientModInitializer {
	public static KeyMapping configKey;

	@Override
	public void onInitializeClient() {
		TridentConfig.load();

		KeyMapping.Category category = KeyMapping.Category.register(
			Identifier.fromNamespaceAndPath("tridentutil", "main")
		);

		configKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
			"key.tridentutil.config",
			InputConstants.Type.KEYSYM,
			InputConstants.KEY_F7,
			category
		));

		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			while (configKey.consumeClick()) {
				mc.setScreen(new TridentConfigScreen(mc.screen));
			}
		});

		TrajectoryPreview.register();
		TridentHud.register();
	}
}
