package dev.tridentutil.gui;

import dev.tridentutil.config.TridentConfig;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;

public class TridentConfigScreen extends Screen {
	private final Screen parent;

	public TridentConfigScreen(Screen parent) {
		super(Component.literal("Trident Util Ayarları"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		TridentConfig c = TridentConfig.get();
		int w = 220;
		int x = this.width / 2 - w / 2;
		int y = this.height / 6;
		int gap = 24;

		addRenderableWidget(toggle(x, y, w, "Riptide boost", () -> c.boostEnabled, v -> c.boostEnabled = v));
		addRenderableWidget(new ValueSlider(x, y + gap, w, "Boost çarpanı", 1.0, 5.0, c.boostMultiplier, false,
			v -> c.boostMultiplier = (float) v));
		addRenderableWidget(toggle(x, y + gap * 2, w, "Yörünge önizleme", () -> c.trajectoryEnabled, v -> c.trajectoryEnabled = v));
		addRenderableWidget(toggle(x, y + gap * 3, w, "Yörünge: elde tutarken göster", () -> c.trajectoryWhileHeld, v -> c.trajectoryWhileHeld = v));
		addRenderableWidget(new ValueSlider(x, y + gap * 4, w, "Yörünge adım sayısı", 20, 400, c.trajectoryMaxSteps, true,
			v -> c.trajectoryMaxSteps = (int) v));
		addRenderableWidget(toggle(x, y + gap * 5, w, "HUD", () -> c.hudEnabled, v -> c.hudEnabled = v));

		addRenderableWidget(Button.builder(Component.literal("Bitti"), b -> onClose())
			.bounds(x, y + gap * 6 + 10, w, 20).build());
	}

	private Button toggle(int x, int y, int w, String label, BooleanSupplier get, Consumer<Boolean> set) {
		return Button.builder(toggleText(label, get.getAsBoolean()), b -> {
			set.accept(!get.getAsBoolean());
			b.setMessage(toggleText(label, get.getAsBoolean()));
		}).bounds(x, y, w, 20).build();
	}

	private static Component toggleText(String label, boolean on) {
		return Component.literal(label + ": " + (on ? "Açık" : "Kapalı"));
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
		super.render(graphics, mouseX, mouseY, delta);
		int titleX = this.width / 2 - this.font.width(this.title) / 2;
		graphics.drawString(this.font, this.title, titleX, 20, 0xFFFFFFFF, true);
	}

	@Override
	public void onClose() {
		TridentConfig.save();
		this.minecraft.setScreen(parent);
	}

	private static class ValueSlider extends AbstractSliderButton {
		private final String label;
		private final double min;
		private final double max;
		private final boolean integer;
		private final DoubleConsumer onChange;

		ValueSlider(int x, int y, int w, String label, double min, double max, double current, boolean integer, DoubleConsumer onChange) {
			super(x, y, w, 20, Component.empty(), (current - min) / (max - min));
			this.label = label;
			this.min = min;
			this.max = max;
			this.integer = integer;
			this.onChange = onChange;
			updateMessage();
		}

		private double real() {
			double v = min + (max - min) * this.value;
			return integer ? Math.round(v) : Math.round(v * 20) / 20.0;
		}

		@Override
		protected void updateMessage() {
			double v = real();
			setMessage(Component.literal(label + ": " + (integer ? String.valueOf((int) v) : String.format("%.2f", v))));
		}

		@Override
		protected void applyValue() {
			onChange.accept(real());
		}
	}
}
