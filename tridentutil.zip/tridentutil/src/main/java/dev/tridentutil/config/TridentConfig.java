package dev.tridentutil.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class TridentConfig {
	public boolean boostEnabled = true;
	public float boostMultiplier = 1.5f;
	public boolean trajectoryEnabled = true;
	public boolean trajectoryWhileHeld = false;
	public int trajectoryMaxSteps = 120;
	public boolean hudEnabled = true;

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("tridentutil.json");
	private static TridentConfig instance = new TridentConfig();

	public static TridentConfig get() {
		return instance;
	}

	public static void load() {
		try {
			if (Files.exists(PATH)) {
				TridentConfig loaded = GSON.fromJson(Files.readString(PATH), TridentConfig.class);
				if (loaded != null) {
					instance = loaded;
				}
			}
		} catch (Exception ignored) {
			instance = new TridentConfig();
		}
		instance.clamp();
		save();
	}

	public static void save() {
		instance.clamp();
		try {
			Files.writeString(PATH, GSON.toJson(instance));
		} catch (IOException ignored) {
		}
	}

	public void clamp() {
		boostMultiplier = Math.max(1.0f, Math.min(5.0f, boostMultiplier));
		trajectoryMaxSteps = Math.max(20, Math.min(400, trajectoryMaxSteps));
	}
}
